import semmle.code.java.dataflow.DataFlow
import semmle.code.java.dataflow.TaintTracking
import semmle.code.java.dataflow.FlowSources
import semmle.code.java.dataflow.ExternalFlow
import semmle.code.java.security.CommandArguments
import semmle.code.java.security.ExternalProcess
import semmle.code.java.security.Sanitizers

//defines sanitizer nodes for UnsafeFileUploadFlowConfig
private class UnsafeFileUploadSanitizer extends DataFlow::Node {
  UnsafeFileUploadSanitizer() {
    this instanceof SimpleTypeSanitizer or
    mimeTypeSanitizer(this) or 
    magicBytesSanitizer(this)
  }
}

//holds if the given candidate sanitizer node is sanitized by a mime-type check
private predicate mimeTypeSanitizer(DataFlow::Node candidateNode) {
  exists (DataFlow::Node sink |
    MimeTypeSanitizerConfig::isSink(sink) and
    MimeTypeSanitizerFlow::flow(candidateNode, sink)
  )
}

//holds if the given candidate sanitizer node is sanitized by a magic bytes check
private predicate magicBytesSanitizer(DataFlow::Node candidateNode) {
  exists (DataFlow::Node sink |
    MimeTypeSanitizerConfig::isSink(sink) and
    MimeTypeSanitizerFlow::flow(candidateNode, sink)
  )
}

module UnsafeFileUploadFlow = TaintTracking::Global<UnsafeFileUploadConfig>; 

private module UnsafeFileUploadConfig implements DataFlow::ConfigSig {
  predicate isSource(DataFlow::Node source) {
    sourceNode(source, "remote")
  }
  predicate isSink(DataFlow::Node sink) {
    exists (MethodCall m | 
      m.getMethod().hasName("write") and
      sink.asExpr() = m.getArgument(0))
  }

  predicate isBarrier(DataFlow::Node node) { node instanceof UnsafeFileUploadSanitizer }

  predicate isAdditionalFlowStep(DataFlow::Node node1, DataFlow::Node node2) {
    none()
  }
}

module MimeTypeSanitizerFlow = TaintTracking::Global<MimeTypeSanitizerConfig>; 

private module MimeTypeSanitizerConfig implements DataFlow::ConfigSig {
  predicate isSource(DataFlow::Node source) {
    sourceNode(source, "remote")
  }
  predicate isSink(DataFlow::Node sink) {
    sinkNode(sink, "mime-type-sanitizer")
  }
}

module MagicBytesSanitizerFlow = TaintTracking::Global<MagicBytesSanitizerConfig>;

private module MagicBytesSanitizerConfig implements DataFlow::ConfigSig {
  predicate isSource(DataFlow::Node source) {
    sourceNode(source, "remote")
  }
  predicate isSink(DataFlow::Node sink) {
    exists(MethodCall m1, MethodCall m2 | 
      ( m1.getMethod().hasName("read") or m1.getMethod().hasName("readAllBytes") ) and
      m2.getMethod().hasName("equals") and
      (DataFlow::localExprFlow(m1.getArgument(0), m2.getArgument(0)) or 
        DataFlow::localExprFlow(m1.getArgument(0), m2.getQualifier())
      ) and
      sink.asExpr() = m1.getQualifier()
    )
  }
}
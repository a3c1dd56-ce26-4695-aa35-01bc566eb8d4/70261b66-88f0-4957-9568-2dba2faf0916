/**
 * Provides a taint-tracking configuration characterising request-forgery risks.
 *
 * Only import this directly from .ql files, to avoid the possibility of polluting the Configuration hierarchy accidentally.
 */

import semmle.code.java.dataflow.FlowSources
import semmle.code.java.security.RequestForgery


class FileIOSource extends DataFlow::ExprNode {
  FileIOSource() {
    exists(Method m | m = this.asExpr().(MethodCall).getMethod() |
      m.hasName("readRange") and
      m.getDeclaringType().hasName("IOUtils")
    )
  }
}

/**
 * A taint-tracking configuration characterising request-forgery risks.
 */
module RequestForgeryConfig implements DataFlow::ConfigSig {
  predicate isSource(DataFlow::Node source) {
    ( 
    source instanceof ActiveThreatModelSource and
    // Exclude results of remote HTTP requests: fetching something else based on that result
    // is no worse than following a redirect returned by the remote server, and typically
    // we're requesting a resource via https which we trust to only send us to safe URLs.
    not source.asExpr().(MethodCall).getCallee() instanceof UrlConnectionGetInputStreamMethod
    ) or 
    source instanceof FileIOSource 
  }

  predicate isSink(DataFlow::Node sink) { sink instanceof RequestForgerySink }

  predicate isAdditionalFlowStep(DataFlow::Node pred, DataFlow::Node succ) {
    any(RequestForgeryAdditionalTaintStep r).propagatesTaint(pred, succ) or 
    exists(MethodCall m |
      m.getMethod().hasName("decode") and
      pred.asExpr() = m.getAnArgument() and
      succ.asExpr() = m
    )
  }

  predicate isBarrier(DataFlow::Node node) { node instanceof RequestForgerySanitizer }

  predicate isBarrierIn(DataFlow::Node node) { isSource(node) }

  predicate observeDiffInformedIncrementalMode() { any() }
}

module RequestForgeryFlow = TaintTracking::Global<RequestForgeryConfig>;

// int explorationLimit() { result = 21 }

// module MyPartialFlow = RequestForgeryFlow::FlowExplorationFwd<explorationLimit/0>;

// predicate adhocPartialFlow(Callable c, MyPartialFlow::PartialPathNode n, DataFlow::Node src, int dist) {
//   exists(MyPartialFlow::PartialPathNode source |
//     MyPartialFlow::partialFlow(source, n, dist) and
//     src = source.getNode() and
//     c = n.getNode().getEnclosingCallable() 
//     and c.getName() = "readCentralDirectoryEntry"
//     // src.getEnclosingCallable().getDeclaringType().getName() = "CompressZipFuzzer"
//   )
// }

// predicate testP(VarAccess va, Variable v) {
//   va.getLocation().getFile().getBaseName() = "SeekableInMemoryByteChannel.java" and
//   va.getLocation().getStartLine() = 65 and 
//   va.getVariable() = v and
//   v.getName() = "data"
// }